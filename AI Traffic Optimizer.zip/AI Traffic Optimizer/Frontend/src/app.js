const form = document.getElementById('traffic-form');
const resultDiv = document.getElementById('result');

form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const timestamp = document.getElementById('timestamp').value;
    const location = document.getElementById('location').value;
    const vehicle_count = document.getElementById('vehicle_count').value;
    const average_speed = document.getElementById('average_speed').value;

    const response = await fetch('http://127.0.0.1:8000/predict', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ timestamp, location, vehicle_count, average_speed }),
    });

    const result = await response.json();
    resultDiv.innerHTML = `<p>Traffic Prediction: ${result.traffic_prediction}</p>
                           <p>Carbon Emission: ${result.carbon_emission.toFixed(2)} kg CO2</p>
                           <p>Travel Time: ${result.travel_time.toFixed(2)} minutes</p>`;
});