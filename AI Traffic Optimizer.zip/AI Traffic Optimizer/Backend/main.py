from fastapi import FastAPI
import uvicorn
from pydantic import BaseModel
import pickle
import numpy as np

class TrafficData(BaseModel):
    timestamp: str
    location: str
    vehicle_count: int
    average_speed: float

app = FastAPI()
with open("../models/traffic_model.pkl", "rb") as f:
    model = pickle.load(f)

@app.post("/predict")
async def predict_traffic(data: TrafficData):
    features = np.array([[data.vehicle_count, data.average_speed]])
    traffic_prediction = model.predict(features)[0]
    emission_factor = 0.25  
    carbon_emission = emission_factor * data.vehicle_count * 1.0  

    travel_time = 10 / (data.average_speed + 1e-5)

    return {
        "timestamp": data.timestamp,
        "location": data.location,
        "traffic_prediction": traffic_prediction,
        "carbon_emission": carbon_emission,
        "travel_time": travel_time
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)