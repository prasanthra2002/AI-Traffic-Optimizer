import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import numpy as np

np.random.seed(42)
vehicle_count = np.random.randint(10, 200, 1000)
average_speed = np.random.uniform(10, 100, 1000)
labels = ["Heavy Traffic" if vc > 100 else "Light Traffic" for vc in vehicle_count]

X = np.column_stack((vehicle_count, average_speed))
y = np.array(labels)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = RandomForestClassifier()
model.fit(X_train, y_train)

predictions = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, predictions))

with open("traffic_model.pkl", "wb") as f:
    pickle.dump(model, f)